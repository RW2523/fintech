@echo off
cd /d %~dp0
python serve_demo.py
pause
