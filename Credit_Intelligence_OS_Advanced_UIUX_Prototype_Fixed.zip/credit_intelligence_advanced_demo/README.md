# Coop Credit Intelligence — Advanced Interactive Prototype

This is a high-fidelity **mock UI/UX application** for the governed Credit Intelligence OS. It uses **synthetic demo data only** and includes sample PDFs, PNG, and CSV files for document-intelligence demonstrations.

## Fastest way to run

### Option A — one HTML file
Open `Credit_Intelligence_OS_Advanced_Standalone.html` in Chrome/Edge/Safari. It contains the app, styles, demo data, and embedded sample evidence.

### Option B — full project (recommended for PDF/file preview)
- macOS: double-click `start_demo.command`
- Windows: double-click `start_demo.bat`
- or run: `python3 serve_demo.py`

The launcher opens the prototype in your browser on a local-only address.

## Main interactive flows

1. **Portfolio Overview** — KPI cards, filters, application trend, AI highlights, priority queue, risk mix, recent evidence.
2. **Applications Queue** — 12 demo cases, search/filter chips, selected-case drawer, bulk actions, direct workbench launch.
3. **Officer Workbench** — AI Credit Council recommendation, confidence/disagreement, expandable agent positions, source evidence, cross-source reconciliation, officer action buttons.
4. **Document Intelligence** — real synthetic PDFs/PNG/CSV, drag/drop upload, file preview, extracted fields, validation checks, reconciliation, exceptions.
5. **Longitudinal Member Intelligence** — perfect-payer drift scenario, personal baseline, change point, 30-day forecast, recovery likelihood, cross-data corroboration, intervention planning.
6. **Collections Intelligence** — prioritized cases, predicted response, selected-case next best action, communication log.
7. **Policy Sandbox** — sliders for DTI/confidence, simulated portfolio impacts, autonomy mode, kill switch.
8. **Decision Ledger** — reconstruct snapshot → agent opinions → recommendation → human action → audit token/event log.
9. **Member Assistant Demo** — identity-scoped Q&A and hardship handoff simulation.
10. **Guided Demo** — click `Guided Demo` in the top bar for an end-to-end walkthrough.

## Included demo files

`demo_files/` contains:
- `payslip_david_carter_mar_2024.pdf`
- `bank_statement_david_carter_q1_2024.pdf`
- `employment_letter_david_carter.pdf`
- `national_id_david_carter.png`
- `salary_deduction_david_carter.csv`
- `member_payment_history_david_carter.csv`
- `business_permit_maria_torres.pdf`
- `income_statement_maria_torres_q1.pdf`

All names, transactions, scores, predictions, policies, and documents are synthetic and are intended only to demonstrate the product experience.

## Prototype scope

This front-end prototype simulates governed AI behavior. It does not connect to real core banking systems, make real credit decisions, or run production ML/LLM models. The UX is structured so that a production backend can later replace the simulated data/services without redesigning the main user flows.
