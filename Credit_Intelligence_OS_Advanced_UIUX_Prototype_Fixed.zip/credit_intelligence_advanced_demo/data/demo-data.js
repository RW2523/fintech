window.DEMO_DATA = {
  currentUser:{name:'Sarah Kim',role:'Operations Lead',initials:'SK'},
  filters:{product:'All Products',branch:'All Branches',period:'Last 14 Days'},
  kpis:{applicationsToday:24,approvalRate:78,avgProcessing:'1.8 days',predictedDelinquency:3.2},
  trend:[
    {d:'Apr 1',a:13,ap:10,de:4},{d:'Apr 2',a:15,ap:11,de:5},{d:'Apr 3',a:14,ap:10,de:4},{d:'Apr 4',a:13,ap:9,de:5},
    {d:'Apr 5',a:18,ap:13,de:5},{d:'Apr 6',a:20,ap:14,de:6},{d:'Apr 7',a:17,ap:12,de:5},{d:'Apr 8',a:23,ap:16,de:7},
    {d:'Apr 9',a:28,ap:22,de:6},{d:'Apr 10',a:20,ap:16,de:4},{d:'Apr 11',a:18,ap:13,de:5},{d:'Apr 12',a:17,ap:12,de:5},
    {d:'Apr 13',a:19,ap:14,de:5},{d:'Apr 14',a:25,ap:18,de:7},{d:'Apr 15',a:28,ap:20,de:7},{d:'Apr 16',a:20,ap:14,de:6}
  ],
  applications:[
    {id:'APP-104328',memberId:'104328',name:'David Carter',initials:'DC',product:'Personal Loan',amount:25000,branch:'Makati',risk:'Moderate',score:743,docs:{v:5,t:6},route:'Officer Review',age:'1d',sla:'3d',next:'Review',status:'Needs Review',submitted:'Apr 15, 2024',income:52000,bankIncome:45200,dti:28,confidence:0.78,disagreement:'1 / 6'},
    {id:'APP-104317',memberId:'104317',name:'Lisa Tan',initials:'LT',product:'Car Loan',amount:32000,branch:'Cebu',risk:'Moderate',score:612,docs:{v:4,t:6},route:'Document Review',age:'7h',sla:'2d',next:'Request Docs',status:'Additional Info',submitted:'Apr 15, 2024',income:69000,bankIncome:68800,dti:37,confidence:0.74,disagreement:'2 / 6'},
    {id:'APP-104310',memberId:'104310',name:'Robert James',initials:'RJ',product:'Personal Loan',amount:15000,branch:'Davao',risk:'High',score:580,docs:{v:6,t:6},route:'Enhanced Review',age:'2d',sla:'3d',next:'Investigate',status:'High Risk',submitted:'Apr 14, 2024',income:41000,bankIncome:32600,dti:48,confidence:0.65,disagreement:'3 / 6'},
    {id:'APP-104298',memberId:'104298',name:'Mei Ying',initials:'MY',product:'Education Loan',amount:18000,branch:'Makati',risk:'Moderate',score:701,docs:{v:5,t:6},route:'Verification',age:'1d',sla:'3d',next:'Verify',status:'In Verification',submitted:'Apr 14, 2024',income:48000,bankIncome:47600,dti:31,confidence:0.81,disagreement:'1 / 6'},
    {id:'APP-104291',memberId:'104291',name:'Siti Khadijah',initials:'SK',product:'Personal Loan',amount:10000,branch:'Cebu',risk:'Moderate',score:665,docs:{v:4,t:6},route:'Officer Review',age:'2d',sla:'3d',next:'Request Docs',status:'Needs Review',submitted:'Apr 14, 2024',income:36000,bankIncome:35800,dti:35,confidence:0.72,disagreement:'2 / 6'},
    {id:'APP-104276',memberId:'104276',name:'Antonio Cruz',initials:'AC',product:'Home Loan',amount:120000,branch:'Makati',risk:'Low',score:782,docs:{v:6,t:6},route:'Credit Analysis',age:'3d',sla:'7d',next:'Review',status:'Officer Review',submitted:'Apr 13, 2024',income:135000,bankIncome:134800,dti:29,confidence:0.91,disagreement:'0 / 6'},
    {id:'APP-104265',memberId:'104265',name:'Sarah Lim',initials:'SL',product:'Personal Loan',amount:10000,branch:'Cebu',risk:'High',score:566,docs:{v:4,t:6},route:'Fraud Review',age:'1d',sla:'2d',next:'Investigate',status:'Fraud Watch',submitted:'Apr 13, 2024',income:39000,bankIncome:28700,dti:46,confidence:0.63,disagreement:'4 / 6'},
    {id:'APP-104241',memberId:'104241',name:'Daniel Brooks',initials:'DB',product:'Business Loan',amount:75000,branch:'Davao',risk:'Moderate',score:689,docs:{v:5,t:6},route:'Risk Review',age:'2d',sla:'5d',next:'Review',status:'Early Warning',submitted:'Apr 12, 2024',income:97000,bankIncome:91800,dti:39,confidence:0.76,disagreement:'2 / 6'},
    {id:'APP-104233',memberId:'104233',name:'Elena Garcia',initials:'EG',product:'Auto Loan',amount:22000,branch:'Makati',risk:'Low',score:804,docs:{v:6,t:6},route:'Auto Approve',age:'6h',sla:'2d',next:'Approve',status:'Low Risk',submitted:'Apr 12, 2024',income:78000,bankIncome:77600,dti:24,confidence:0.94,disagreement:'0 / 6'},
    {id:'APP-104201',memberId:'104201',name:'Kevin Wu',initials:'KW',product:'Personal Loan',amount:8500,branch:'Cebu',risk:'Moderate',score:676,docs:{v:4,t:6},route:'Officer Review',age:'2d',sla:'3d',next:'Request Docs',status:'Needs Review',submitted:'Apr 11, 2024',income:42000,bankIncome:40500,dti:33,confidence:0.74,disagreement:'2 / 6'},
    {id:'APP-104188',memberId:'104188',name:'Maria Torres',initials:'MT',product:'Business Loan',amount:50000,branch:'Makati',risk:'Moderate',score:682,docs:{v:3,t:6},route:'Officer Review',age:'2d',sla:'5d',next:'Request Docs',status:'Officer Review',submitted:'Apr 10, 2024',income:65000,bankIncome:62000,dti:32,confidence:0.77,disagreement:'2 / 6'},
    {id:'APP-104172',memberId:'104172',name:'James Lee',initials:'JL',product:'Auto Loan',amount:28000,branch:'Cebu',risk:'Low',score:798,docs:{v:6,t:6},route:'Auto Approve',age:'4h',sla:'2d',next:'Approve',status:'Low Risk',submitted:'Apr 10, 2024',income:83000,bankIncome:82400,dti:26,confidence:0.93,disagreement:'0 / 6'}
  ],
  files:[
    {id:'f1',name:'payslip_david_carter_mar_2024.pdf',label:'payslip_mar2024.pdf',type:'pdf',status:'Verified',confidence:98,owner:'David Carter',uploaded:'Mar 15, 2024 10:24',path:'demo_files/payslip_david_carter_mar_2024.pdf'},
    {id:'f2',name:'bank_statement_david_carter_q1_2024.pdf',label:'bank_statement_q1.pdf',type:'pdf',status:'Verified',confidence:96,owner:'David Carter',uploaded:'Mar 15, 2024 10:25',path:'demo_files/bank_statement_david_carter_q1_2024.pdf'},
    {id:'f3',name:'employment_letter_david_carter.pdf',label:'employment_letter.pdf',type:'pdf',status:'Verified',confidence:97,owner:'David Carter',uploaded:'Mar 15, 2024 10:27',path:'demo_files/employment_letter_david_carter.pdf'},
    {id:'f4',name:'national_id_david_carter.png',label:'national_id.png',type:'img',status:'Verified',confidence:99,owner:'David Carter',uploaded:'Mar 15, 2024 10:30',path:'demo_files/national_id_david_carter.png'},
    {id:'f5',name:'salary_deduction_david_carter.csv',label:'salary_deduction_march.csv',type:'csv',status:'Verified',confidence:100,owner:'David Carter',uploaded:'Mar 15, 2024 10:32',path:'demo_files/salary_deduction_david_carter.csv'},
    {id:'f6',name:'member_payment_history_david_carter.csv',label:'payment_history.csv',type:'csv',status:'Verified',confidence:100,owner:'David Carter',uploaded:'Mar 15, 2024 10:33',path:'demo_files/member_payment_history_david_carter.csv'},
    {id:'f7',name:'business_permit_maria_torres.pdf',label:'business_permit.pdf',type:'pdf',status:'Verified',confidence:97,owner:'Maria Torres',uploaded:'Apr 10, 2024 08:25',path:'demo_files/business_permit_maria_torres.pdf'},
    {id:'f8',name:'income_statement_maria_torres_q1.pdf',label:'income_statement_q1.pdf',type:'pdf',status:'Needs Review',confidence:92,owner:'Maria Torres',uploaded:'Apr 10, 2024 08:27',path:'demo_files/income_statement_maria_torres_q1.pdf'}
  ],
  council:[
    {id:'doc',name:'Document Agent',tone:'green',stance:'Support',summary:'Required evidence is readable and authentic; one income variance is disclosed.',detail:'Documents are complete for the current review path. The net-pay to bank-deposit variance is 5.1% and must remain visible to the officer.'},
    {id:'policy',name:'Policy Agent',tone:'blue',stance:'Support',summary:'All hard policy gates pass; affordability remains within the standard product range.',detail:'DTI is 28%, member tenure satisfies minimums, and the requested amount is within the officer authority band.'},
    {id:'risk',name:'Risk Agent',tone:'amber',stance:'Caution',summary:'Moderate calibrated risk driven by recent inquiries and utilization.',detail:'Risk score 743. Positive payment conduct offsets recent inquiry activity; no hard adverse factor is present.'},
    {id:'fraud',name:'Fraud Agent',tone:'green',stance:'Support',summary:'No identity mismatch, duplicate document, or suspicious graph link detected.',detail:'Document hashes are unique across the synthetic corpus. Identity fields reconcile with core member data.'},
    {id:'member',name:'Member Relationship Agent',tone:'blue',stance:'Support',summary:'Long-standing member with strong repayment and cooperative engagement.',detail:'Four-year relationship, consistent contributions, no prior serious delinquency, and positive servicing history.'},
    {id:'challenger',name:'Challenger',tone:'purple',stance:'Concern',summary:'Requests explicit confirmation that income variance is non-material.',detail:'The emerging recommendation may be wrong if bank deposits exclude recurring obligations or if the payslip variance persists. Recommends verifying one additional month.'}
  ],
  reconciliation:[
    ['Monthly Income','$52,000','$43,000','$45,200','Review'],
    ['Employer','TechCorp Inc.','TechCorp Inc.','TechCorp Inc.','Match'],
    ['Salary Deduction','$620','$620','$620','Match'],
    ['Employment Status','Employed','Employed','Employed','Match']
  ],
  lmi:{
    member:{name:'David Carter',memberId:'104328',product:'Personal Loan',balance:18250,branch:'Makati',state:'ELEVATED'},
    payments:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,8],
    months:['Jan 23','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan 24','Feb','Mar','Apr'],
    changePoint:'42 days ago',lateForecast:68,recovery:72,
    signals:[
      {name:'Irregular salary deduction',detail:'2 delayed deductions in the last 2 cycles',tone:'amber',badge:'Concerning'},
      {name:'Lower savings contribution',detail:'30% decrease vs. prior 6-month baseline',tone:'amber',badge:'Concerning'},
      {name:'Increased support contacts',detail:'3 support inquiries in the last 45 days',tone:'blue',badge:'Notable'},
      {name:'No fraud indicators',detail:'Identity, device, and document checks remain clear',tone:'green',badge:'Positive'}
    ],
    agents:[
      {name:'Behaviour Trend Agent',tone:'blue',badge:'Concern',summary:'Clear shift from stable to late behavior after 14 months of perfect payment.'},
      {name:'Cross-Data Investigator',tone:'blue',badge:'Notable',summary:'Salary-deduction timing and savings changes corroborate a possible stress signal.'},
      {name:'Forecast Agent',tone:'amber',badge:'Concern',summary:'Late-payment probability remains elevated without early intervention.'},
      {name:'Intervention Planner',tone:'purple',badge:'Support',summary:'Strong prior history and recovery potential favor supportive outreach, not adverse action.'}
    ]
  },
  collections:[
    {id:'COL-1001',member:'James Wilson',initials:'JW',memberId:'104328',balance:4850,dpd:'120 DPD',response:72,intervention:'Phone call + hardship options',priority:'P1',lastPayment:'Jan 12, 2024',delinquency:78},
    {id:'COL-1002',member:'Sandra Lee',initials:'SL',memberId:'981204',balance:2340,dpd:'90 DPD',response:65,intervention:'SMS with payment link',priority:'P1',lastPayment:'Jan 30, 2024',delinquency:74},
    {id:'COL-1003',member:'Marcus Rivera',initials:'MR',memberId:'776310',balance:1920,dpd:'60 DPD',response:58,intervention:'Call + refinance review',priority:'P2',lastPayment:'Feb 18, 2024',delinquency:66},
    {id:'COL-1004',member:'Emily Tran',initials:'ET',memberId:'662118',balance:3600,dpd:'45 DPD',response:66,intervention:'Offer hardship options',priority:'P2',lastPayment:'Mar 02, 2024',delinquency:64},
    {id:'COL-1005',member:'Daniel Kim',initials:'DK',memberId:'553901',balance:980,dpd:'30 DPD',response:49,intervention:'SMS + financial education',priority:'P3',lastPayment:'Mar 12, 2024',delinquency:52},
    {id:'COL-1006',member:'Alicia Chen',initials:'AC',memberId:'441276',balance:5200,dpd:'High Risk',response:71,intervention:'Proactive call (at risk)',priority:'P1',lastPayment:'Apr 08, 2024',delinquency:73}
  ],
  communicationLog:[
    {type:'call',title:'Outbound Call',time:'Apr 24, 2024 10:15 AM',text:'Spoke with member. Discussed past-due balance and hardship options. Member requested time to review.'},
    {type:'sms',title:'SMS Sent',time:'Apr 20, 2024 2:03 PM',text:'Sent payment link and account summary.'},
    {type:'promise',title:'Promise to Pay',time:'Apr 12, 2024 11:20 AM',text:'Member promised $300 payment on Apr 26, 2024.'},
    {type:'call',title:'Outbound Call',time:'Apr 5, 2024 4:10 PM',text:'Left voicemail. No response.'}
  ],
  audit:[
    ['Apr 15 10:24:01','Application Received','System','Initial application submitted'],
    ['Apr 15 10:24:05','Policy Evaluation','Policy Agent','Hard gates pass; DTI 28%'],
    ['Apr 15 10:24:07','Risk Evaluation','Risk Agent','Score 743 - Moderate'],
    ['Apr 15 10:24:10','Fraud Evaluation','Fraud Agent','Clear - no critical signal'],
    ['Apr 15 10:24:12','Decision Synthesized','Synthesizer','Approve recommendation; confidence 0.81'],
    ['Apr 15 10:24:13','Officer Route Created','Workflow','Human-in-the-loop'],
    ['Apr 15 10:26:42','Human Decision','Sarah Kim','Approved with standard terms'],
    ['Apr 15 10:26:43','Ledger Hash Appended','Audit Service','Decision record sealed']
  ],
  memberAssistantSeed:[
    {role:'assistant',text:'Hi David. I can help with your balance, next payment, application status, required documents, or arrange a support callback.'}
  ]
};
