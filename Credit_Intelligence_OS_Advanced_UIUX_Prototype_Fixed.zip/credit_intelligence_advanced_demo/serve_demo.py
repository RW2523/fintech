#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, socket, threading, webbrowser

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

def free_port(start=8000):
    for port in range(start, start+50):
        with socket.socket() as s:
            try:
                s.bind(('127.0.0.1', port))
                return port
            except OSError:
                pass
    return 8765

port = free_port()
url = f'http://127.0.0.1:{port}/index.html'
print(f'\nCoop Credit Intelligence prototype running at:\n  {url}\n')
print('Press Ctrl+C to stop the demo server.\n')
threading.Timer(0.8, lambda: webbrowser.open(url)).start()
ThreadingHTTPServer(('127.0.0.1', port), SimpleHTTPRequestHandler).serve_forever()
