#!/bin/bash
cd "$(dirname "$0")"
python3 serve_demo.py
